﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance.Classes
{
    internal class Araba
    {
       public string vites;
       public string marka;
        public void Yazdir(string marka, string vites)
        {
            Console.WriteLine( marka +" "+ vites);
        }
    }

    

}

